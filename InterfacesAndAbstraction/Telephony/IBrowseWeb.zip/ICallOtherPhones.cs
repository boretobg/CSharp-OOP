﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony
{
    public interface ICallOtherPhones
    {
        void CallOtherPhones(string number);
    }
}
