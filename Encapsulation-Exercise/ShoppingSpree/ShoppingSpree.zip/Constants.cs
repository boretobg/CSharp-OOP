﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ShoppingSpree
{
    public class Constants
    {
        public const string EmptyStringException = "Name cannot be empty";
        public const string NoMoneyException = "Money cannot be negative";
    }
}
