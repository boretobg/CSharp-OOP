﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Contracts
{
    public abstract class Food
    {
        public abstract int Quantity { get; set; }
    }
}
