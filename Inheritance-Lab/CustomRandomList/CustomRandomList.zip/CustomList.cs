﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CustomRandomList
{
    public class CustomList : List<string>
    {
        public string RandomString()
        {
            Random rnd = new Random();
            int index = rnd.Next(base.Count);
            string output = base[index];
            base.RemoveAt(index);
            return output;
        }
    }
}
