﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shapes
{
    public class Rectangle : Shape
    {
        private float height;
        private float width;

        public Rectangle(float height, float width)
        {
            this.height = height;
            this.width = width;
        }
        public override float CalculateArea()
        {
            return height * width;
        }

        public override float CalculatePerimeter() //2(l+w)
        {
            return 2 * (height + width);
        }
        public override string Draw()
        {
            return "Drawing rectangle";
        }
    }
}
