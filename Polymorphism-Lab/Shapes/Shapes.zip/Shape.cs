﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shapes
{
    public abstract class Shape
    {
        public abstract float CalculatePerimeter();
        public abstract float CalculateArea();
        public virtual string Draw()
        {
            return "Drawing shape";
        }

    }
}
