﻿namespace RobotService.Utilities
{
    public enum RobotTypeEnums
    {
        HouseholdRobot = 1,
        PetRobot = 2,
        WalkerRobot = 3
    }
}
