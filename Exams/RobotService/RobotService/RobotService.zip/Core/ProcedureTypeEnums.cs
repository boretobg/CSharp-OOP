﻿namespace RobotService.Core
{
    internal class ProcedureTypeEnums
    {
    }
}