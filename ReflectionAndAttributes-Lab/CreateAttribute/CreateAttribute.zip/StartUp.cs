﻿using System;

namespace AuthorProblem
{
    [AuthorAttribute("Ventsi")]
    class StartUp
    {
        [AuthorAttribute("Gosho")]
        static void Main(string[] args)
        {
        }
    }

}
